# 使用说明

本文档介绍如何将本项目应用到一个普通 Java Spring Boot 后端项目中。

---

## 1. 服务器目录建议

```text
/opt/apps/demo-backend/
├── current/              # 当前运行版本
│   └── demo-backend.jar
├── release/              # Jenkins 上传的新发布包
│   └── demo-backend.jar
├── releases/             # 历史备份版本
├── logs/                 # 应用日志
├── scripts/              # 运维脚本
└── config/               # 配置文件
```

---

## 2. 初始化目录

```bash
mkdir -p /opt/apps/demo-backend/{current,release,releases,logs,scripts,config}
```

将本项目中的 `scripts` 和 `config/deploy.conf.example` 上传到服务器对应目录。

```bash
cp config/deploy.conf.example config/deploy.conf
vim config/deploy.conf
chmod +x scripts/*.sh
```

---

## 3. 手动测试发布

先把一个 JAR 包放到 release 目录：

```bash
cp demo-backend.jar /opt/apps/demo-backend/release/demo-backend.jar
```

执行发布：

```bash
cd /opt/apps/demo-backend
bash scripts/deploy_jar.sh
```

查看服务状态：

```bash
bash scripts/app.sh status
```

查看日志：

```bash
bash scripts/app.sh logs
```

---

## 4. Jenkins 集成建议

Jenkins 中建议配置以下凭据：

- Git 仓库凭据；
- 目标服务器 SSH 用户；
- 目标服务器地址；
- SSH 私钥或密码；
- 生产环境人工确认节点。

不要把账号、密码、Token、生产 IP 写死到 Jenkinsfile 或 GitHub 仓库中。

---

## 5. 生产环境注意事项

生产发布建议保留以下人工确认动作：

1. 确认发布版本；
2. 确认备份已完成；
3. 确认数据库 SQL 已准备；
4. 确认回滚包可用；
5. 确认发布窗口；
6. 发布后确认服务状态和业务功能。

---

## 6. 常见问题

### 6.1 启动后服务马上退出怎么办？

查看日志：

```bash
bash scripts/app.sh logs
```

重点检查：

- 端口是否被占用；
- 配置文件是否正确；
- 数据库连接是否正常；
- JDK 版本是否匹配；
- JAR 包是否完整。

### 6.2 releases 目录为什么没有自动清理？

检查 `config/deploy.conf`：

```bash
MAX_RELEASES=10
```

同时确认 `scripts/clean_releases.sh` 有执行权限。

### 6.3 Jenkins 无法连接生产服务器怎么办？

常见原因：

- Jenkins 所在服务器无法访问生产网段；
- 生产环境需要 VPN；
- 防火墙未开放 SSH；
- SSH 凭据配置错误；
- 生产环境禁止从测试机直接访问。

如果生产环境必须通过公司电脑 VPN 访问，可以采用“Jenkins 构建包 + 人工 VPN 发布”的分段发布模式。
