#!/usr/bin/env bash
set -euo pipefail

BASE_DIR=$(cd "$(dirname "$0")/.." && pwd)
CONF_FILE="$BASE_DIR/config/deploy.conf"

if [ ! -f "$CONF_FILE" ]; then
  echo "配置文件不存在：$CONF_FILE"
  echo "请先执行：cp config/deploy.conf.example config/deploy.conf"
  exit 1
fi

# shellcheck source=/dev/null
source "$CONF_FILE"

mkdir -p "$LOG_DIR" "$CURRENT_DIR"
LOG_FILE="$LOG_DIR/${APP_NAME}.log"
PID_FILE="$CURRENT_DIR/${APP_NAME}.pid"
JAR_PATH="$CURRENT_DIR/$JAR_NAME"

get_pid() {
  if [ -f "$PID_FILE" ]; then
    local pid
    pid=$(cat "$PID_FILE")
    if ps -p "$pid" > /dev/null 2>&1; then
      echo "$pid"
      return 0
    fi
  fi

  pgrep -f "$JAR_PATH" || true
}

start() {
  if [ ! -f "$JAR_PATH" ]; then
    echo "JAR 包不存在：$JAR_PATH"
    exit 1
  fi

  local pid
  pid=$(get_pid)
  if [ -n "$pid" ]; then
    echo "服务已经运行，PID：$pid"
    exit 0
  fi

  echo "启动服务：$APP_NAME"
  nohup java $JAVA_OPTS -jar "$JAR_PATH" $APP_OPTS >> "$LOG_FILE" 2>&1 &
  echo $! > "$PID_FILE"
  sleep 3

  pid=$(get_pid)
  if [ -n "$pid" ]; then
    echo "启动成功，PID：$pid"
  else
    echo "启动失败，请查看日志：$LOG_FILE"
    exit 1
  fi
}

stop() {
  local pid
  pid=$(get_pid)
  if [ -z "$pid" ]; then
    echo "服务未运行"
    rm -f "$PID_FILE"
    return 0
  fi

  echo "停止服务，PID：$pid"
  kill "$pid" || true

  for i in {1..20}; do
    if ! ps -p "$pid" > /dev/null 2>&1; then
      echo "服务已停止"
      rm -f "$PID_FILE"
      return 0
    fi
    sleep 1
  done

  echo "普通停止超时，执行强制停止"
  kill -9 "$pid" || true
  rm -f "$PID_FILE"
}

restart() {
  stop
  start
}

status() {
  local pid
  pid=$(get_pid)
  if [ -n "$pid" ]; then
    echo "服务运行中，PID：$pid"
  else
    echo "服务未运行"
    exit 1
  fi
}

logs() {
  tail -n 200 -f "$LOG_FILE"
}

case "${1:-}" in
  start)
    start
    ;;
  stop)
    stop
    ;;
  restart)
    restart
    ;;
  status)
    status
    ;;
  logs)
    logs
    ;;
  *)
    echo "用法：$0 {start|stop|restart|status|logs}"
    exit 1
    ;;
esac
