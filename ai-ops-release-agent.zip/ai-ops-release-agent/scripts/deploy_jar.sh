#!/usr/bin/env bash
set -euo pipefail

BASE_DIR=$(cd "$(dirname "$0")/.." && pwd)
CONF_FILE="$BASE_DIR/config/deploy.conf"

if [ ! -f "$CONF_FILE" ]; then
  echo "配置文件不存在：$CONF_FILE"
  exit 1
fi

# shellcheck source=/dev/null
source "$CONF_FILE"

NEW_JAR="$RELEASE_DIR/$JAR_NAME"
CURRENT_JAR="$CURRENT_DIR/$JAR_NAME"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_PATH="$BACKUP_DIR/${APP_NAME}_${TIMESTAMP}.jar"

mkdir -p "$CURRENT_DIR" "$RELEASE_DIR" "$BACKUP_DIR" "$LOG_DIR"

if [ ! -f "$NEW_JAR" ]; then
  echo "新发布包不存在：$NEW_JAR"
  exit 1
fi

echo "========== 开始部署 =========="
echo "应用名称：$APP_NAME"
echo "新发布包：$NEW_JAR"
echo "当前目录：$CURRENT_DIR"

if [ -f "$CURRENT_JAR" ]; then
  echo "备份当前版本：$BACKUP_PATH"
  cp "$CURRENT_JAR" "$BACKUP_PATH"
else
  echo "当前版本不存在，跳过备份"
fi

echo "停止旧服务"
bash "$BASE_DIR/scripts/app.sh" stop || true

echo "替换 JAR 包"
cp "$NEW_JAR" "$CURRENT_JAR"

echo "启动新服务"
bash "$BASE_DIR/scripts/app.sh" start

echo "检查服务状态"
bash "$BASE_DIR/scripts/app.sh" status

echo "清理历史备份"
bash "$BASE_DIR/scripts/clean_releases.sh"

echo "========== 部署完成 =========="
