#!/usr/bin/env bash
set -euo pipefail

BASE_DIR=$(cd "$(dirname "$0")/.." && pwd)
CONF_FILE="$BASE_DIR/config/deploy.conf"

if [ ! -f "$CONF_FILE" ]; then
  echo "配置文件不存在：$CONF_FILE"
  exit 1
fi

# shellcheck source=/dev/null
source "$CONF_FILE"

mkdir -p "$BACKUP_DIR"

MAX_RELEASES=${MAX_RELEASES:-10}

echo "备份目录：$BACKUP_DIR"
echo "最多保留版本数：$MAX_RELEASES"

count=$(find "$BACKUP_DIR" -maxdepth 1 -type f -name "*.jar" | wc -l)
echo "当前备份数量：$count"

if [ "$count" -le "$MAX_RELEASES" ]; then
  echo "无需清理"
  exit 0
fi

remove_count=$((count - MAX_RELEASES))
echo "需要清理旧版本数量：$remove_count"

find "$BACKUP_DIR" -maxdepth 1 -type f -name "*.jar" -printf '%T@ %p\n' \
  | sort -n \
  | head -n "$remove_count" \
  | awk '{print $2}' \
  | while read -r file; do
      echo "删除旧备份：$file"
      rm -f "$file"
    done

echo "清理完成"
