# 上传到 GitHub 的步骤

## 方式一：网页上传

1. 打开 GitHub；
2. 点击右上角 `+`；
3. 选择 `New repository`；
4. Repository name 填：`ai-ops-release-agent`；
5. Description 填：`Jenkins + Shell + AI assisted Java release workflow`；
6. 建议选择 `Public`，作为作品集展示；
7. 不要勾选初始化 README，因为项目里已经有 README；
8. 创建仓库后，把本项目文件上传即可。

---

## 方式二：命令行上传

进入项目目录后执行：

```bash
git init
git add .
git commit -m "init ai ops release agent"
git branch -M main
git remote add origin https://github.com/你的GitHub用户名/ai-ops-release-agent.git
git push -u origin main
```

---

## 建议仓库描述

```text
A lightweight AI-assisted DevOps release workflow for Java applications, including Jenkins Pipeline, shell deployment scripts, release backup cleanup and operation documents.
```

---

## 建议 Topics

```text
jenkins, devops, shell, linux, java, springboot, deployment, ai-agent, automation, sre
```
