# AI Ops Release Agent

一个面向中小型 Java 后端项目的轻量级 AI 运维发布工作流示例，主要用于辅助完成 Jenkins 自动化构建、JAR 包部署、服务启停、版本备份、历史发布包清理、磁盘空间治理和发布流程标准化。

> 本项目适合作为 GitHub 展示项目、AI Agent 实践项目、运维自动化作品集项目使用。  
> 注意：请勿在仓库中提交真实服务器 IP、账号、密码、Token、客户名称、公司内部域名等敏感信息。

---

## 1. 项目背景

在传统发布流程中，Java 后端项目通常需要人工完成以下步骤：

- 手动打包前后端项目；
- 上传 JAR 包或静态资源；
- 登录服务器备份旧版本；
- 停止旧服务；
- 替换新包；
- 启动服务；
- 查看日志确认服务状态；
- 手动清理历史备份包和无用日志。

这些操作重复度高，且容易因为人工遗漏导致发布失败、版本混乱或磁盘空间占满。

本项目通过 Jenkins Pipeline + Shell 脚本 + AI 辅助流程设计的方式，将常见发布动作沉淀为标准化、可复用的自动化发布流程。

---

## 2. 核心痛点

| 痛点 | 说明 | 解决方式 |
|---|---|---|
| 发布步骤重复 | 每次发布都要手动上传、备份、重启 | 使用 Jenkins Pipeline 串联发布流程 |
| JAR 服务管理不规范 | 启停命令分散，排查不方便 | 使用统一 `app.sh` 管理 start/stop/restart/status/log |
| 备份目录无限增长 | releases 目录长期积累占用磁盘 | 使用自动清理脚本保留最近 N 个版本 |
| 故障排查效率低 | 日志查看和进程检查依赖经验 | 标准化日志、端口、进程检查步骤 |
| 生产发布风险高 | 人工操作容易误删、误传、漏备份 | 发布前校验 + 自动备份 + 可回滚目录结构 |

---

## 3. 项目成果

本项目提供了一套可直接改造使用的自动化发布模板：

- `Jenkinsfile`：Jenkins 自动化构建与发布流水线示例；
- `scripts/app.sh`：Java JAR 服务启停脚本；
- `scripts/deploy_jar.sh`：JAR 包部署脚本；
- `scripts/clean_releases.sh`：历史发布包自动清理脚本；
- `config/deploy.conf.example`：部署配置模板；
- `docs/usage.md`：使用说明；
- `docs/proof.md`：项目证明材料整理模板；
- `docs/token-plan.md`：AI 平台填写用 Token/额度说明模板；
- `agent/workflow.md`：AI Agent 工作流设计说明；
- `agent/prompts.md`：常用 AI 提示词模板。

---

## 4. 核心逻辑流程

```mermaid
flowchart TD
    A[开发提交代码] --> B[Jenkins 拉取代码]
    B --> C[Maven 构建 JAR 包]
    C --> D[归档构建产物]
    D --> E[上传到目标服务器]
    E --> F[备份当前版本]
    F --> G[停止旧服务]
    G --> H[替换新 JAR 包]
    H --> I[启动新服务]
    I --> J[检查进程/端口/日志]
    J --> K{发布是否成功}
    K -- 是 --> L[清理历史备份]
    K -- 否 --> M[保留现场并人工排查/回滚]
```

---

## 5. AI Agent 设计说明

本项目中的 AI Agent 并不是直接接管服务器权限的全自动 Agent，而是一个运维辅助型 Agent 工作流，主要承担以下职责：

1. 帮助拆解发布链路，形成标准化流程；
2. 生成 Jenkins Pipeline、Shell 脚本和部署说明；
3. 根据错误日志辅助分析故障原因；
4. 帮助整理发布前检查清单和回滚方案；
5. 辅助生成项目复盘、日报、证明材料和 GitHub 文档。

这种方式适合真实生产环境，因为 AI 不直接持有生产权限，最终执行仍由运维人员确认，既能提升效率，又能降低误操作风险。

---

## 6. 目录结构

```text
ai-ops-release-agent/
├── Jenkinsfile
├── README.md
├── LICENSE
├── .gitignore
├── config/
│   └── deploy.conf.example
├── scripts/
│   ├── app.sh
│   ├── deploy_jar.sh
│   └── clean_releases.sh
├── agent/
│   ├── workflow.md
│   └── prompts.md
├── docs/
│   ├── usage.md
│   ├── proof.md
│   └── token-plan.md
├── examples/
│   └── release-log.example.md
└── assets/
    └── .gitkeep
```

---

## 7. 快速开始

### 7.1 克隆项目

```bash
git clone https://github.com/yourname/ai-ops-release-agent.git
cd ai-ops-release-agent
```

### 7.2 修改配置

```bash
cp config/deploy.conf.example config/deploy.conf
vim config/deploy.conf
```

### 7.3 授权脚本

```bash
chmod +x scripts/*.sh
```

### 7.4 启动服务

```bash
./scripts/app.sh start
```

### 7.5 查看状态

```bash
./scripts/app.sh status
```

---

## 8. 适用场景

- Java Spring Boot 单体项目；
- 中小型公司后端发布流程；
- Jenkins 手动构建或半自动构建；
- JAR 包部署模式；
- 不方便直接打通 VPN/生产机的分段发布场景；
- 运维自动化作品集展示；
- AI Agent 实践成果展示。

---

## 9. 安全说明

请在真实项目中注意以下事项：

- 不要提交真实服务器 IP、账号、密码、私钥；
- 不要将生产环境 Token 写入 GitHub；
- Jenkins 凭据应使用 Credentials 管理；
- 生产发布建议保留人工确认节点；
- Shell 脚本上线前必须在测试环境验证；
- 删除、清理、回滚类命令必须谨慎使用。

---

## 10. 后续优化方向

- 增加 Docker 镜像构建与 Harbor 推送；
- 增加灰度发布能力；
- 增加健康检查接口校验；
- 增加飞书/企业微信发布通知；
- 增加发布失败自动回滚；
- 增加多环境配置管理；
- 增加 Web UI 发布面板；
- 增加 AI 日志分析模块。

---

## 11. License

MIT License
